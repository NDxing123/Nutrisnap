//
//  Coredata controller.swift
//  Nutrisnap
//
//  Created by Donald Ng on 21/03/2024.
//

import Foundation
import CoreData
import UIKit

class CoreDataManager {
    static let shared = CoreDataManager()


    lazy var persistentContainer: NSPersistentContainer = {
            let container = NSPersistentContainer(name: "NutritionModel")
            container.loadPersistentStores(completionHandler: { (storeDescription, error) in
                if let error = error as NSError? {
                    fatalError("Unresolved error \(error), \(error.userInfo)")
                }
            })
            return container
        }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    
    func saveNutritionInfo(carbs: Int, calories: Int, fat: Int, protein: Int,date: Date,proteinPOD:Double,fatPOD:Double,caloriesPOD:Double,carbsPOD:Double) {
        let sushiNutrition = SushiNutrition(context: context)
        sushiNutrition.carbs = carbs
        sushiNutrition.calories = calories
        sushiNutrition.fat = fat
        sushiNutrition.protein = protein
        sushiNutrition.date = date
        sushiNutrition.proteinPOD = proteinPOD
        sushiNutrition.fatPOD = fatPOD
        sushiNutrition.caloriesPOD = caloriesPOD
        sushiNutrition.carbsPOD = carbsPOD
        
        do {
            try context.save()  
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }

    }

    func fetchNutritionInfo() -> [SushiNutrition]? {
            let fetchRequest: NSFetchRequest<SushiNutrition> = SushiNutrition.fetchRequest()

            do {
                let results = try context.fetch(fetchRequest)
                return results
            } catch {
                print("Failed to fetch nutrition info: \(error.localizedDescription)")
                return nil
            }
    }
    
    func deleteNutritionalInfo(){
        let context = persistentContainer.viewContext // Replace with your NSManagedObjectContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "SushiNutrition")
        fetchRequest.predicate = NSPredicate(format: "calories == %d", 570)

        do {
            let objects = try context.fetch(fetchRequest)
            for object in objects {
                context.delete(object)
            }
            
            
            try context.save()
        } catch let error as NSError {
            print("Error: \(error.localizedDescription)")
        }

    }
    
    
  
    
    func fetchLastWeeksNutritionData() -> [Date: Int] {
        let fetchRequest: NSFetchRequest<SushiNutrition> = SushiNutrition.fetchRequest()
        let calendar = Calendar.current
        let dateSevenDaysAgo = calendar.startOfDay(for: calendar.date(byAdding: .day, value: -7, to: Date())!)
        fetchRequest.predicate = NSPredicate(format: "date >= %@", dateSevenDaysAgo as NSDate)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]
        
        do {
            let results = try context.fetch(fetchRequest)
            let groupedResults = Dictionary(grouping: results, by: { calendar.startOfDay(for: $0.date) })

            var dailyCalories = [Date: Int]()
            for (date, sushiNutritions) in groupedResults {
                let totalCalories = sushiNutritions.reduce(0) { $0 + $1.calories }
                dailyCalories[date] = totalCalories
            }

            return dailyCalories
        } catch {
            print("Failed to fetch last week's nutrition info: \(error.localizedDescription)")
            return [:]
        }
    }

    
    
}
