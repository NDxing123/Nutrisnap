//
//  SushiNutrition+CoreDataClass.swift
//  Nutrisnap
//
//  Created by Donald Ng on 21/03/2024.
//
//

import Foundation
import CoreData

@objc(SushiNutrition)
public class SushiNutrition: NSManagedObject {

}
