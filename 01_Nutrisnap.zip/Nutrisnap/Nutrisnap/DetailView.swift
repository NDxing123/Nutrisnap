//
//  DetailView.swift
//  Nutrisnap
//
//  Created by Donald Ng on 26/01/2024.
//

import Charts
import SwiftUI
import Foundation
import CoreData

struct Item: Identifiable {
    let id = UUID()
    let date: Date
    let calories: Int
}

struct Nutrisnap: App {
    // Initialize the Core Data stack
    let coreDataManager = CoreDataManager.shared

    var body: some Scene {
        WindowGroup {
            DetailView()
                // Inject the managed object context into the SwiftUI environment
                .environment(\.managedObjectContext, coreDataManager.context)
        }
    }
}

struct DetailView: View {
    @Environment(\.presentationMode) var presentationMode
    //@State private var lastWeeksItems: [SushiNutrition] = []
    @Environment(\.managedObjectContext) private var context
    @State private var lastWeeksItems: [Item] = []
    
    private var dateFormatter: DateFormatter {
           let formatter = DateFormatter()
           formatter.dateFormat = "yyyy-MM-dd" // Use your desired date format
           return formatter
       }

  
    var body: some View {

            NavigationView{
                ZStack {
                                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.black]),
                                               startPoint: .topLeading, endPoint: .bottomTrailing)
                                    .edgesIgnoringSafeArea(.all)
                    ScrollView{
                    VStack{
                        HStack{
                            Spacer()
                            Button{action: do {
                                self.presentationMode.wrappedValue.dismiss()
                         
                                
                            }
                                
                            }
                        label:{
                            Image(systemName: "xmark")
                                .foregroundColor(.black)
                                .imageScale(.large)
                                .frame(width:34,height:34)
                        }
                        }
                        .padding()
                        //insert graph
                        if !lastWeeksItems.isEmpty {
                            Text("calories intake for the past week")
                            Chart {
                                ForEach(lastWeeksItems) { item in
                                    BarMark(
                                        x: .value("Date", item.date , unit:.day),
                                        y: .value("Calories", item.calories)
                                    )
                                    
                                    
                                }
                            }  
                            

                            
        
                            .frame(height: 300)
                            .padding()

                                               }
                        Spacer()
                    }
                   
                }
                .navigationTitle("statistics")
            }
            .background(Color.blue.opacity(0.1))
            .edgesIgnoringSafeArea(.bottom)
            .onAppear {
                
                        fetchDataForLastWeek()
                       
                        }
        }
    }
    
 
    private func fetchDataForLastWeek() {
        let dailyCaloriesDict = CoreDataManager.shared.fetchLastWeeksNutritionData()
        print(dailyCaloriesDict)
        let sortedDates = dailyCaloriesDict.keys.sorted()
        print(sortedDates)
        let calendar = Calendar.current

        lastWeeksItems = sortedDates.map { date in
            let dayStart = calendar.startOfDay(for: date)
            let calories = dailyCaloriesDict[date] ?? 0
            //print (dayStart)
            return Item(date: dayStart, calories: calories)
        }
    }
    

       
    
    


}

#Preview {
    DetailView()
}
