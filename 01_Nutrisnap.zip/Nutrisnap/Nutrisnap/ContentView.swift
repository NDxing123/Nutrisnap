import SwiftUI
import CoreML
import CoreData

struct BarChartView: View {
    var nutritionData: NutritionData
    private let maxValue: CGFloat // Maximum value to help scale the bars
    private let scaleFactor: CGFloat // Scaling factor based on maxValue

    init(nutritionData: NutritionData) {
        self.nutritionData = nutritionData
        maxValue = CGFloat(max(nutritionData.carbsInt, nutritionData.proteinInt, nutritionData.caloriesInt, nutritionData.fatInt))
        scaleFactor = maxValue > 0 ? 150 / maxValue : 1 // Assuming 150 is the max height for any bar
    }

    var body: some View {
        HStack(alignment: .bottom, spacing: 12) {
            BarView(value: CGFloat(nutritionData.carbsInt), label: "Carbs", scaleFactor: scaleFactor)
            BarView(value: CGFloat(nutritionData.proteinInt), label: "Protein", scaleFactor: scaleFactor)
            BarView(value: CGFloat(nutritionData.caloriesInt), label: "Calories", scaleFactor: scaleFactor)
            BarView(value: CGFloat(nutritionData.fatInt), label: "Fat", scaleFactor: scaleFactor)
        }.padding()
    }

    struct BarView: View {
        var value: CGFloat
        var label: String
        var scaleFactor: CGFloat
        var body: some View {
            VStack {
                Text("\(Int(value))g")
                    .font(.caption)
                Rectangle()
                    .fill(Color.blue)
                    .frame(width: 20, height: value * scaleFactor) // Use the scaleFactor for dynamic height adjustment
                Text(label)
                    .font(.caption)
            }
        }
    }
}


    
struct NutritionData {
    var carbsInt: Int
    var proteinInt: Int
    var caloriesInt: Int
    var fatInt: Int
    var date: Date
    var carbsPOD : Double
    var proteinPOD : Double
    var caloriesPOD : Double
    var fatPOD : Double

    init(carbsInt: Int = 0, proteinInt: Int = 0, caloriesInt: Int = 0, fatInt: Int = 0, date: Date) {
        self.carbsInt = carbsInt
        self.proteinInt = proteinInt
        self.caloriesInt = caloriesInt
        self.fatInt = fatInt
        self.date = date
        self.proteinPOD = 0
        self.fatPOD = 0
        self.caloriesPOD = 0
        self.carbsPOD = 0
    }
}

// Create a static function to generate the specific date
extension NutritionData {
    static func defaultDate() -> Date {
        var dateComponents = DateComponents()
        dateComponents.year = 2023
        dateComponents.month = 12
        dateComponents.day = 1
        return Calendar.current.date(from: dateComponents) ?? Date()
    }
}


struct ContentView: View {
    @State private var nutritionData = NutritionData(date: NutritionData.defaultDate())
    @State private var selectedID: UUID = UUID()
    @State private var text = "info"
    @State private var showingImagePicker = false
    @State private var selectedImage: UIImage?
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var predictionLabel : String? 
    @State private var predictionProbabilities = [String: Double]()
    @State private var carbs: String?
    @State private var fat: String?
    @State private var calories: String?
    @State private var protein: String?

    


    let columns: [GridItem] = [GridItem(.flexible()),
                               GridItem(.flexible()),
                               GridItem(.flexible())]
    
    

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.black]),
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    Text("Nutrisnap")
                        .font(.system(size: 32, weight: .medium))
                        .padding()
                    LazyVGrid(columns: columns) {
                        Button(action: {
                            self.sourceType = .camera
                            self.showingImagePicker = true
                        }){
                            VStack {
                                Image(systemName: "camera.fill")
                                    .renderingMode(.original)
                                    .resizable()
                                    .frame(width: 100, height: 80)
                                Text("take a photo")
                                    .font(.system(size: 15, weight: .medium))
                            }
                        }
                        Button(action: {
                            self.sourceType = .photoLibrary
                            self.showingImagePicker = true
                        }) {
                            VStack {
                                Image(systemName: "photo.fill")
                                    .renderingMode(.original)
                                    .resizable()
                                    .frame(width: 100, height: 80)
                                Text("select a photo")
                                    .font(.system(size: 15, weight: .medium))
                            }
                        }
                        NavigationLink(destination: DetailView()) {
                            VStack {
                                Image(systemName: "list.bullet")
                                    .resizable()
                                    .frame(width: 100, height: 80)
                                Text("Statistics")
                                    .font(.system(size: 15, weight: .medium))
                            }
                        }
                    } //end of grid
                    
    
                        
                    Text("Prediction: \(predictionLabel ?? "insert a picture")")
                    Text("carbs: \( carbs ?? "insert a picture")")
                    Text("protein: \( protein ?? "insert a picture")")
                    Text("fat: \( fat ?? "insert a picture")")
                    Text("calories: \( calories ?? "insert a picture")")
             
                    //integrate bar chart view here
                    BarChartView(nutritionData: nutritionData)
                                        .padding()
                                        .frame(height: 200) // You can adjust the height as neede
                    Text("percentage of daily needs (carbs): \( nutritionData.proteinPOD)")
                    Text("percentage of daily needs (protein): \( nutritionData.carbsPOD)")
                    Text("percentage of daily needs (fat): \( nutritionData.fatPOD)")
                    Text("percentage of daily needs (calories): \( nutritionData.caloriesPOD)")
                    
                    
                    Spacer()
                }
            }
            .sheet(isPresented: $showingImagePicker,onDismiss: classifySelectedImage) {
                ImagePicker(sourceType: sourceType, selectedImage: $selectedImage)
            }
        }
    }
    
    
    func classifySelectedImage() {
           guard let selectedImage = selectedImage, let imageBuffer = buffer(from: selectedImage) else {
               print("Failed to convert UIImage to CVPixelBuffer")
               return
           }

           do {
               let config = MLModelConfiguration()
               let model = try classifier(configuration: config)
               let predictionResult = try model.prediction(image: imageBuffer)
    
            
               self.predictionLabel = predictionResult.target
       
               self.predictionProbabilities = predictionResult.targetProbability

               if let highestProbability = self.predictionProbabilities.max(by: { a, b in a.value < b.value }) {
                    let confidenceThreshold = 0.7
                    if highestProbability.value > confidenceThreshold {
                    
                        let apiManager = APImanager()
                        apiManager.getFood(query: self.predictionLabel ?? "") { recipeId in
                            DispatchQueue.main.async {
                                if let recipeId = recipeId {
                
                                    
                                    // Now fetch the nutritional information for this recipe ID
                                    apiManager.getNutritional(id: recipeId) { result in
                                        DispatchQueue.main.async {
                                            switch result {
                                            case .success(_):
                                                
                                                let sushiNutritionArray = CoreDataManager.shared.fetchNutritionInfo()
                                                print(sushiNutritionArray)
                                                for sushiNutrition in sushiNutritionArray! {
                                                    nutritionData.carbsInt = sushiNutrition.carbs
                                                    nutritionData.proteinInt = sushiNutrition.protein
                                                    nutritionData.caloriesInt = sushiNutrition.calories
                                                    nutritionData.fatInt = sushiNutrition.fat
                                                    print(sushiNutrition.date)
                                                    nutritionData.proteinPOD = sushiNutrition.proteinPOD
                                                    nutritionData.fatPOD = sushiNutrition.fatPOD
                                                    nutritionData.caloriesPOD = sushiNutrition.caloriesPOD
                                                    nutritionData.carbsPOD = sushiNutrition.carbsPOD
                                                    nutritionData.date = sushiNutrition.date
                                                    carbs = "\(nutritionData.carbsInt)g"
                                                    protein = "\(nutritionData.proteinInt)g"
                                                    calories = "\(nutritionData.caloriesInt)g"
                                                    fat = "\(nutritionData.fatInt)g"
                                                }
                                        

                                                
                                                
                                            case .failure(let error):
                                                // Handle the error here
                                                print("Failed to retrieve nutrition info for recipe ID \(recipeId): \(error.localizedDescription)")
                                            }
                                        }
                                    }
                                } else {
                                    print("No recipe found or an error occurred")
                                }
                            }
                        }
                        
                        } 
                   else {
                            self.predictionLabel = "The item is not recognized"
                            }
                        }
                   
               
           } catch {
               print("Error during model setup or image classification: \(error)")
           }
       }

  
}



func buffer(from image: UIImage) -> CVPixelBuffer? {
  let attributes = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
  var pixelBuffer : CVPixelBuffer?
  let status = CVPixelBufferCreate(kCFAllocatorDefault, Int(image.size.width), Int(image.size.height), kCVPixelFormatType_32ARGB, attributes , &pixelBuffer)
 
guard (status == kCVReturnSuccess) else {
    return nil
  }

  CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
  let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

  let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
  let context = CGContext(data: pixelData, width: Int(image.size.width), height: Int(image.size.height), bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)

  context?.translateBy(x: 0, y: image.size.height)
  context?.scaleBy(x: 1.0, y: -1.0)

  UIGraphicsPushContext(context!)
  image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
  UIGraphicsPopContext()
  CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

  return pixelBuffer
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
    
    
    
}

