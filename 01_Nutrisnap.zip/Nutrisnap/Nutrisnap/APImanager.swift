import Foundation
import CoreData

struct FoodResponse: Codable {
    let results: [Food]
}

struct Food: Codable {
    let id: Int
    let title: String
    let image: String
    let imageType: String
}

struct nutrition : Codable {
    let calories: String
    let carbs: String
    let fat: String
    let protein: String
    let bad: [Nutrient]
    let good: [Nutrient]
    let nutrients: [NutrientDetail]
}

struct Nutrient: Codable {
    let amount: String
    let indented: Bool
    let title: String
    let percentOfDailyNeeds: Double
}

// Define a structure for detailed nutrient information.
struct NutrientDetail: Codable {
    let name: String
    let amount: Double
    let unit: String
    let percentOfDailyNeeds: Double
}


class APImanager {
    let apiKey = ""

    
    func getFood(query: String, completion: @escaping (Int?) -> Void) {
        
        var components = URLComponents(string: "https://api.spoonacular.com/recipes/complexSearch")
        components?.queryItems = [
            URLQueryItem(name: "query", value: query),
            URLQueryItem(name: "apiKey", value: apiKey)
        ]
        
        guard let url = components?.url else {
            completion(nil)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print("Invalid response: \(String(describing: response))")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("No data received.")
                completion(nil)
                return
            }
            
            do {
                let decodedResponse = try JSONDecoder().decode(FoodResponse.self, from: data)
                //print("Foods: \(decodedResponse.results)")
                if let firstId = decodedResponse.results.first?.id {
                    completion(firstId)
                } else {
                    completion(nil)
                }
                
            } catch {
                print("Error decoding response data: \(error.localizedDescription)")
                completion(nil)
            }
        }
        task.resume()
    }


    func getNutritional(id: Int, completion: @escaping (Result<nutrition, Error>) -> Void) {
        var caloriesAmountInt:Int = 0
        var carbohydratesAmountInt : Int=0
        var fatAmountInt:Int = 0
        var proteinAmountInt:Int=0
        
        
        var components = URLComponents(string: "https://api.spoonacular.com/recipes/\(id)/nutritionWidget.json")
        components?.queryItems = [
            URLQueryItem(name: "apiKey", value: apiKey)
        ]
        
        guard let url = components?.url else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Unable to construct URL"])))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid response status code"])))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data received"])))
                return
            }
            
            do {
                
                let decodedResponse = try JSONDecoder().decode(nutrition.self, from: data)
               
                    
                // Save the date for next time
                let currentdate = Date()
                //let calendar = Calendar.current
                //var dateComponents = DateComponents()
               // dateComponents.year = calendar.component(.year, from: Date())
               // dateComponents.month = 4  // March
               // dateComponents.day = 5
                //let currentdate = calendar.date(from: dateComponents)
                let carbohydratesInfo = decodedResponse.bad.first { $0.title == "Carbohydrates" }
                let caloriesInfo = decodedResponse.bad.first { $0.title == "Calories" }
                let fatInfo = decodedResponse.bad.first { $0.title == "Fat" }
                let proteinInfo = decodedResponse.good.first { $0.title == "Protein" }
                let proteinPOD = proteinInfo?.percentOfDailyNeeds
                let carbsPOD = carbohydratesInfo?.percentOfDailyNeeds
                let caloriesPOD = caloriesInfo?.percentOfDailyNeeds
                let fatPOD = fatInfo?.percentOfDailyNeeds
                    // Update the outer variables with parsed values (ensure they're declared outside this closure)
                    if let carbsAmount = carbohydratesInfo?.amount.filter("0123456789".contains), let carbsInt = Int(carbsAmount) {
                        carbohydratesAmountInt = carbsInt
                    }
                    if let caloriesAmount = caloriesInfo?.amount.filter("0123456789".contains), let caloriesInt = Int(caloriesAmount) {
                        caloriesAmountInt = caloriesInt
                    }
                    if let fatAmount = fatInfo?.amount.filter("0123456789".contains), let fatInt = Int(fatAmount) {
                        fatAmountInt = fatInt
                    }
                    if let proteinAmount = proteinInfo?.amount.filter("0123456789".contains), let proteinInt = Int(proteinAmount) {
                        proteinAmountInt = proteinInt
                    }


                //delete for testing only
                //CoreDataManager.shared.deleteNutritionalInfo()
                //print(dateToSave)
                CoreDataManager.shared.saveNutritionInfo(carbs: carbohydratesAmountInt, calories: caloriesAmountInt, fat: fatAmountInt, protein: proteinAmountInt,date:currentdate, proteinPOD: proteinPOD!,fatPOD:fatPOD!,caloriesPOD:caloriesPOD!, carbsPOD: carbsPOD!)
                
                
                
                
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }


}



