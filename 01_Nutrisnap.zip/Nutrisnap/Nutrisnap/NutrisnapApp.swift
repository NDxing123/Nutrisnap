//
//  NutrisnapApp.swift
//  Nutrisnap
//
//  Created by Donald Ng on 25/01/2024.
//

import SwiftUI

@main
struct NutrisnapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
