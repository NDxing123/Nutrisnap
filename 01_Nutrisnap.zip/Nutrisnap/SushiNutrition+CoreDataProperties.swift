//
//  SushiNutrition+CoreDataProperties.swift
//  Nutrisnap
//
//  Created by Donald Ng on 21/03/2024.
//
//

import Foundation
import CoreData


extension SushiNutrition {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SushiNutrition> {
        return NSFetchRequest<SushiNutrition>(entityName: "SushiNutrition")
    }

    @NSManaged public var calories: Int
    @NSManaged public var caloriesPOD : Double
    @NSManaged public var carbs: Int
    @NSManaged public var carbsPOD: Double
    @NSManaged public var fat: Int
    @NSManaged public var fatPOD : Double
    @NSManaged public var protein: Int
    @NSManaged public var proteinPOD: Double
    @NSManaged public var date: Date

}

extension SushiNutrition : Identifiable {
    
}
